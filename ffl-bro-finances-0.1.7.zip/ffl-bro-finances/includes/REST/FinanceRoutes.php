<?php
namespace FFLBRO\Fin\REST;
class FinanceRoutes { const NS='fflbro/v1/finance'; public function register(){
 register_rest_route(self::NS,'/ping',array('methods'=>'GET','permission_callback'=>function(){return current_user_can('ffl_fin_read');},'callback'=>function(){return new \WP_REST_Response(array('ok'=>true,'ver'=>FFLBRO_FIN_VER));},));
 register_rest_route(self::NS,'/vendors',array('methods'=>'GET','permission_callback'=>function(){return current_user_can('ffl_fin_read');},'callback'=>array($this,'list_vendors'),));
 register_rest_route(self::NS,'/checks/prepare',array('methods'=>'POST','permission_callback'=>function(){return current_user_can('ffl_fin_manage');},'callback'=>array($this,'prepare_checks'),'args'=>array('payment_ids'=>array('required'=>true),'bank_account_id'=>array('required'=>true)),)); }
 public function list_vendors($req){ global $wpdb; $p=$wpdb->prefix.'fflbro_fin_'; $rows=$wpdb->get_results("SELECT id,name,status FROM {$p}vendors ORDER BY name ASC", ARRAY_A); return new \WP_REST_Response(array('vendors'=>$rows)); }
 public function prepare_checks($req){ $ids=(array)($req['payment_ids']??array()); return new \WP_REST_Response(array('batch_id'=>time(),'count'=>count($ids))); } }
