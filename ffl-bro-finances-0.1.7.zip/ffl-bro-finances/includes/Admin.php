<?php
namespace FFLBRO\Fin;
class Admin { public function register_menus(){
 add_menu_page('FFL-BRO Finances','Finances','ffl_fin_read','fflbro-finances',array($this,'render_dashboard'),'dashicons-money-alt',58);
 add_submenu_page('fflbro-finances','Vendors','Vendors','ffl_fin_manage','fflbro-finances-vendors',array($this,'render_vendors'));
 add_submenu_page('fflbro-finances','Bills','Bills','ffl_fin_manage','fflbro-finances-bills',array($this,'render_bills'));
 add_submenu_page('fflbro-finances','Payments','Payments','ffl_fin_manage','fflbro-finances-payments',array($this,'render_payments'));
 add_submenu_page('fflbro-finances','Check Generator','Check Generator','ffl_fin_manage','fflbro-finances-checks',array($this,'render_checks'));
 add_submenu_page('fflbro-finances','Exports','Exports','ffl_fin_admin','fflbro-finances-exports',array($this,'render_exports'));
 add_submenu_page('fflbro-finances','Settings','Settings','ffl_fin_admin','fflbro-finances-settings',array($this,'render_settings')); }
 public function render_dashboard(){ echo '<div class="wrap"><h1>Finances Dashboard</h1><p>AP Aging, Payment Queue, Bank balances (coming soon).</p></div>'; }
 public function render_vendors(){ echo '<div class="wrap"><h1>Vendors</h1><p>CRUD grid coming next.</p></div>'; }
 public function render_bills(){ echo '<div class="wrap"><h1>Bills</h1><p>Bill editor and approvals coming next.</p></div>'; }
 public function render_payments(){ echo '<div class="wrap"><h1>Payments</h1><p>Scheduler & queue coming next.</p></div>'; }
 public function render_checks(){ echo '<div class="wrap"><h1>Check Generator</h1><p>Prepare batch → PDF → mark printed.</p></div>'; }
 public function render_exports(){ echo '<div class="wrap"><h1>Exports</h1><p>Positive Pay, QB/Xero, NACHA mock.</p></div>'; }
 public function render_settings(){ echo '<div class="wrap"><h1>Settings</h1><p>Banks, MICR, COA.</p></div>'; } }
