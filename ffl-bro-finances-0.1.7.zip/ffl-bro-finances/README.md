# FFL-BRO Finances (AP) — v0.1.7

Crash‑proof AP skeleton for Vendors → Bills → Payments → Check Generator.
- WP 5.8+, PHP 7.4+
- REST: /wp-json/fflbro/v1/finance

Toggle:
```
wp option add fflbro_fin_enable 0
wp option update fflbro_fin_enable 1
```

Tables: vendors, addresses, bills, bill_items, payments, checks, bank_accounts, coa, journal, journal_lines, attachments, audit.

Built 2025-09-29
