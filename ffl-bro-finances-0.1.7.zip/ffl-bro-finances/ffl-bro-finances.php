<?php
/**
 * Plugin Name: FFL-BRO Finances (AP)
 * Description: Accounts Payable module for FFL-BRO: Vendors → Bills → Payments → Check Generator / Positive Pay. REST + wp-admin UI.
 * Version: 0.1.7
 * Author: Neefeco Arms
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

define('FFLBRO_FIN_VER','0.1.7');
define('FFLBRO_FIN_SLUG','ffl-bro-finances');
define('FFLBRO_FIN_PATH',__DIR__);
define('FFLBRO_FIN_URL',plugin_dir_url(__FILE__));

spl_autoload_register(function($class){
  if (0 === strpos($class,'FFLBRO\\\\Fin\\\\')) {
    $rel = str_replace('FFLBRO\\\\Fin\\\\','',$class);
    $rel = str_replace('\\\\','/',$rel);
    $file = __DIR__.'/includes/'.$rel.'.php';
    if (is_file($file)) require $file;
  }
});

function fflbro_fin_notice($msg,$type='error'){
  if (!is_admin() || !current_user_can('activate_plugins')) return;
  add_action('admin_notices', function() use ($msg,$type){
    printf('<div class="notice notice-%s"><p><strong>FFL-BRO Finances:</strong> %s</p></div>', esc_attr($type), esc_html($msg));
  });
}

function fflbro_fin_preflight(){
  $err = array(); global $wp_version;
  if (version_compare(PHP_VERSION, '7.4', '<')) $err[] = 'PHP 7.4+ required';
  if (isset($wp_version) && version_compare($wp_version, '5.8', '<')) $err[] = 'WordPress 5.8+ required';
  foreach (array('includes/Schema.php','includes/Admin.php','includes/REST/FinanceRoutes.php') as $f){
    if (!is_file(FFLBRO_FIN_PATH.'/'.$f)) $err[] = 'Missing file: '.$f;
  }
  if (!function_exists('dbDelta')){
    if (file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) require_once ABSPATH.'wp-admin/includes/upgrade.php';
    if (!function_exists('dbDelta')) $err[] = 'dbDelta() missing';
  }
  return $err;
}

register_activation_hook(__FILE__, function(){
  $e = fflbro_fin_preflight();
  if ($e){
    deactivate_plugins(plugin_basename(__FILE__));
    wp_die('<h1>Activation blocked</h1><ul><li>'.implode('</li><li>', array_map('esc_html',$e)).'</li></ul>');
  }
  foreach (array('administrator','editor') as $role){
    if ($r = get_role($role)){
      foreach (array('ffl_fin_admin','ffl_fin_manage','ffl_fin_read') as $c) $r->add_cap($c);
    }
  }
  try{
    $s = new \\FFLBRO\\Fin\\Schema();
    if (method_exists($s,'install')) $s->install();
  } catch (\\Throwable $t){
    deactivate_plugins(plugin_basename(__FILE__));
    fflbro_fin_notice('Activation failed: '.$t->getMessage());
    wp_die('Activation failed and was rolled back.');
  }
});

add_action('plugins_loaded', function(){
  $errs = fflbro_fin_preflight();
  if ($errs){ fflbro_fin_notice('Not loading (preflight): '.implode('; ', $errs)); return; }
  $enabled = (int) get_option('fflbro_fin_enable', 0);
  if (!$enabled){ fflbro_fin_notice('Finances is installed but disabled (toggle off)','warning'); return; }

  add_action('admin_menu', function(){ (new \\FFLBRO\\Fin\\Admin())->register_menus(); });
  add_action('rest_api_init', function(){ (new \\FFLBRO\\Fin\\REST\\FinanceRoutes())->register(); });
  add_action('admin_enqueue_scripts', function($hook){
    if (false !== strpos($hook, 'ffl-bro_page_fflbro-finances') || false !== strpos($hook, 'toplevel_page_fflbro-finances')) {
      wp_enqueue_style('fflbro-fin-admin', FFLBRO_FIN_URL.'assets/admin.css', array(), FFLBRO_FIN_VER);
    }
  });
});
